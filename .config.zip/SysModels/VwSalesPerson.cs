﻿using System;
using System.Collections.Generic;

namespace Ortho_xact_api.SysModels;

public partial class VwSalesPerson
{
    public string Salesperson { get; set; } = null!;

    public string Name { get; set; } = null!;
}
