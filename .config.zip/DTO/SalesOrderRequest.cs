﻿namespace Ortho_xact_api.DTO
{
    public class SalesOrderRequest
    {
        public string? SalesOrderNumber { get; set; }
    }
}
