﻿namespace Ortho_xact_api.DTO
{
    public class LoginRequests
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
