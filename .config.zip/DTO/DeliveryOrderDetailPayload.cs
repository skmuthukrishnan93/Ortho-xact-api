﻿namespace Ortho_xact_api.DTO
{
    public class DeliveryOrderDetailPayload
    {
        public List<DeliveryOrderDetailDto> Data { get; set; } = new();
    }
}
