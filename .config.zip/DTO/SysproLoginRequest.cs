﻿namespace Ortho_xact_api.DTO
{
    public class SysproLoginRequest
    {
        public string Company { get; set; }
        public string Operator { get; set; }
        public string Password { get; set; }
    }

}
